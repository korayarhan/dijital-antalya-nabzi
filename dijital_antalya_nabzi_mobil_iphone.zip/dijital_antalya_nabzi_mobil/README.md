# Dijital Antalya Nabzı - 7 Günlük Otomatik Deneme Sürümü

Bu paket, Antalya yerel gündemini dijital kaynaklardan takip etmek için hazırlanmış küçük ama gerçekçi bir MVP'dir.

## Ne yapar?

- Google News RSS üzerinden kamuya açık haberleri toplar.
- Config dosyasında tanımlı yerel RSS kaynaklarını tarar.
- X API anahtarı verilirse son 7 gün araması yapabilir.
- YouTube API anahtarı verilirse kanal/video araması yapılabilir.
- Mesut Kocagöz, Kepez Belediyesi, Antalya Büyükşehir ve 19 ilçe için anahtar kelime takibi yapar.
- İçerikleri ilçe, konu, duygu, risk ve fırsat olarak sınıflandırır.
- SQLite veritabanına kaydeder.
- Günlük CSV özet üretir.
- 7 gün sonunda PDF rapor üretir.
- Streamlit ile basit panel açabilir.

## Kurulum

```bash
cd dijital_antalya_nabzi_7gun
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## İlk test

```bash
python run_daily.py --demo
python run_report.py --days 7
```

Rapor `reports/` klasörüne düşer.

## Gerçek kaynaklarla çalıştırma

```bash
python run_daily.py
```

API anahtarları opsiyoneldir. `.env.example` dosyasını `.env` yapıp doldurabilirsin.

## 7 günlük otomatik kullanım

Her gün bir kez çalıştır:
```bash
python run_daily.py
```

7. gün:
```bash
python run_report.py --days 7
```

GitHub Actions ile otomatik çalıştırmak için `.github/workflows/daily.yml` örneği hazırdır.

## Önemli sınırlar

Bu sistem:
- Kamuya açık kaynakları takip eder.
- Sahte hesap, gizli yönlendirme, kapalı grup kazıma veya kişisel veri toplamaya yönelik değildir.
- Platformların API ve kullanım kurallarına uyacak şekilde tasarlanmıştır.

