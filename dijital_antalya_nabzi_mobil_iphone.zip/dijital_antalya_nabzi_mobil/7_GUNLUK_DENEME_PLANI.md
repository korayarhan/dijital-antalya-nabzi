# 7 Günlük Otomatik Deneme Planı

## Hedef
Bu denemenin hedefi, 7 gün boyunca kamuya açık dijital kaynaklardan veri toplayıp otomatik rapor üretmektir.

## Günlük çalışan işlem
1. RSS ve haber kaynaklarını çeker.
2. X ve YouTube API anahtarı varsa sosyal medya verisini çeker.
3. API anahtarı yoksa demo veriyle sistemi test eder.
4. Her içeriği ilçe, konu, duygu, risk, fırsat ve Mesut Kocagöz bağlantısı olarak sınıflandırır.
5. SQLite veritabanına kaydeder.

## 7. gün çıkan rapor
- Yönetici özeti
- İlçe görünürlüğü
- Konu dağılımı
- Riskli başlıklar
- Fırsat başlıkları
- Mesut Kocagöz dijital karnesi
- Stratejik notlar

## Çalıştırma
```bash
python run_daily.py
python run_report.py --days 7
streamlit run app.py
```

## En gerçekçi ilk kullanım
İlk hafta RSS kaynakları ve Google News ile başlamak en pratik yoldur. X ve YouTube API anahtarları eklenirse sistem daha güçlü çalışır.

## Etik sınırlar
- Kapalı gruplar kazınmaz.
- Kişisel veri toplanmaz.
- Sahte hesap veya yapay etkileşim üretilmez.
- Amaç dijital dinleme, analiz ve raporlamadır.
