from src.utils import normalize, load_yaml

KEYWORDS = load_yaml("config/keywords.yaml")

def find_district(text):
    t = normalize(text)
    best = None
    for district, words in KEYWORDS["districts"].items():
        for w in words:
            if normalize(w) in t:
                return district
    return "Genel Antalya"

def find_topic(text):
    t = normalize(text)
    scores = {}
    for topic, words in KEYWORDS["topics"].items():
        scores[topic] = sum(1 for w in words if normalize(w) in t)
    topic, score = max(scores.items(), key=lambda x: x[1])
    return topic if score > 0 else "genel"

def is_mesut_related(text):
    t = normalize(text)
    words = KEYWORDS["entities"]["mesut"] + KEYWORDS["entities"]["kepez_belediyesi"]
    return any(normalize(w) in t for w in words)

def sentiment(text):
    t = normalize(text)
    pos = sum(1 for w in KEYWORDS["positive_words"] if normalize(w) in t)
    neg = sum(1 for w in KEYWORDS["negative_words"] if normalize(w) in t)
    if neg > pos:
        return "olumsuz"
    if pos > neg:
        return "olumlu"
    return "nötr"

def risk_score(text):
    t = normalize(text)
    base = sum(1 for w in KEYWORDS["risk_words"] if normalize(w) in t)
    if sentiment(text) == "olumsuz":
        base += 1
    return max(1, min(5, base))

def opportunity_score(text):
    t = normalize(text)
    score = 1
    if is_mesut_related(text):
        score += 2
    if sentiment(text) == "olumlu":
        score += 1
    if any(k in t for k in ["genç", "kadın", "üretici", "esnaf", "sosyal", "mahalle", "ziyaret"]):
        score += 1
    return max(1, min(5, score))

def summarize(title, text):
    raw = f"{title}. {text}".strip()
    if len(raw) <= 260:
        return raw
    return raw[:257] + "..."

def analyze_item(item):
    full = f"{item.get('title','')} {item.get('text','')}"
    item["district"] = find_district(full)
    item["topic"] = find_topic(full)
    item["sentiment"] = sentiment(full)
    item["risk_score"] = risk_score(full)
    item["opportunity_score"] = opportunity_score(full)
    item["mesut_related"] = is_mesut_related(full)
    item["summary"] = summarize(item.get("title",""), item.get("text",""))
    return item
