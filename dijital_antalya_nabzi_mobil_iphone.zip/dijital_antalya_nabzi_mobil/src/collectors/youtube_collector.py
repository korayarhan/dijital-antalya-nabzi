import os, requests
from src.utils import now_iso

def collect_youtube_search(query, max_results=10):
    key = os.getenv("YOUTUBE_API_KEY")
    if not key:
        return []
    url = "https://www.googleapis.com/youtube/v3/search"
    params = {
        "key": key,
        "q": query,
        "part": "snippet",
        "type": "video",
        "maxResults": max_results,
        "order": "date",
        "relevanceLanguage": "tr"
    }
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    items = []
    for it in r.json().get("items", []):
        sn = it.get("snippet", {})
        vid = it.get("id", {}).get("videoId")
        items.append({
            "collected_at": now_iso(),
            "date": sn.get("publishedAt", ""),
            "platform": "youtube",
            "source": sn.get("channelTitle", "YouTube"),
            "title": sn.get("title", ""),
            "text": sn.get("description", ""),
            "url": f"https://www.youtube.com/watch?v={vid}" if vid else ""
        })
    return items
