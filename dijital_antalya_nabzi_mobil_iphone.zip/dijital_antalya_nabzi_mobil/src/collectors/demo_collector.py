import csv
from src.utils import now_iso

def collect_demo(path="data/demo_items.csv"):
    items = []
    with open(path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row["collected_at"] = now_iso()
            items.append(row)
    return items
