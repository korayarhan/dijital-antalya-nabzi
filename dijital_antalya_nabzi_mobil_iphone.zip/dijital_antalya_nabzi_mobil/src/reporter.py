from pathlib import Path
import sqlite3, csv
from datetime import datetime, timedelta
from collections import Counter
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics

DB_PATH = Path("data/antalya_nabzi.sqlite")
REPORT_DIR = Path("reports")

def _load(days=7):
    since = (datetime.now() - timedelta(days=days)).isoformat(timespec="seconds")
    if not DB_PATH.exists():
        return []
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("SELECT * FROM items WHERE collected_at >= ? ORDER BY collected_at DESC", [since]).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def _register_font():
    candidates = ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"]
    for p in candidates:
        if Path(p).exists():
            pdfmetrics.registerFont(TTFont("TRFont", p))
            return "TRFont"
    return "Helvetica"

def _table(data, widths=None):
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#e8eef7")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.HexColor("#1f2937")),
        ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#d1d5db")),
        ("FONTNAME", (0,0), (-1,-1), "TRFont"),
        ("FONTSIZE", (0,0), (-1,-1), 8),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f9fafb")]),
    ]))
    return t

def generate_pdf(days=7, out_path=None):
    REPORT_DIR.mkdir(exist_ok=True)
    font = _register_font()
    out_path = out_path or REPORT_DIR / f"dijital_antalya_nabzi_{datetime.now().date()}_{days}gun.pdf"
    rows = _load(days)
    doc = SimpleDocTemplate(str(out_path), pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TRTitle", parent=styles["Title"], fontName=font, fontSize=18, leading=22, spaceAfter=12))
    styles.add(ParagraphStyle(name="TRH2", parent=styles["Heading2"], fontName=font, fontSize=13, leading=16, spaceBefore=10, spaceAfter=6))
    styles.add(ParagraphStyle(name="TRBody", parent=styles["BodyText"], fontName=font, fontSize=9.5, leading=13))
    story = [
        Paragraph("Dijital Antalya Nabzı - 7 Günlük Otomatik Deneme Raporu", styles["TRTitle"]),
        Paragraph("Amaç: Kamuya açık dijital kaynaklardan Antalya yerel gündemini, 19 ilçe hassasiyetlerini ve Mesut Kocagöz dijital görünürlüğünü izlemek.", styles["TRBody"]),
        Spacer(1, 10)
    ]
    if not rows:
        story.append(Paragraph("Bu dönem için veri bulunamadı. Önce run_daily.py çalıştırılmalıdır.", styles["TRBody"]))
        doc.build(story)
        return str(out_path)
    total = len(rows)
    mesut = sum(1 for r in rows if r.get("mesut_related") == 1)
    risk = sum(1 for r in rows if int(r.get("risk_score") or 0) >= 4)
    opp = sum(1 for r in rows if int(r.get("opportunity_score") or 0) >= 4)
    positives = sum(1 for r in rows if r.get("sentiment") == "olumlu")
    negatives = sum(1 for r in rows if r.get("sentiment") == "olumsuz")
    story.append(Paragraph("Yönetici Özeti", styles["TRH2"]))
    story.append(_table([["Gösterge", "Değer"], ["Toplam içerik", total], ["Mesut Kocagöz bağlantılı içerik", mesut], ["Yüksek riskli başlık", risk], ["Yüksek fırsat başlığı", opp], ["Olumlu / Olumsuz", f"{positives} / {negatives}"]], [260, 220]))
    story.append(Paragraph("İlçe Görünürlüğü", styles["TRH2"]))
    dist = Counter(r.get("district") or "Belirsiz" for r in rows).most_common(20)
    story.append(_table([["İlçe", "İçerik adedi"]] + [[k, v] for k, v in dist], [300, 120]))
    story.append(Paragraph("Konu Dağılımı", styles["TRH2"]))
    topics = Counter(r.get("topic") or "genel" for r in rows).most_common()
    story.append(_table([["Konu", "Adet"]] + [[k, v] for k, v in topics], [300, 120]))
    story.append(Paragraph("Riskli Başlıklar", styles["TRH2"]))
    risky = sorted(rows, key=lambda r: int(r.get("risk_score") or 0), reverse=True)[:10]
    risk_rows = [["İlçe", "Konu", "Risk", "Başlık / Özet"]]
    for r in risky:
        risk_rows.append([r.get("district"), r.get("topic"), str(r.get("risk_score")), Paragraph(str(r.get("summary")), styles["TRBody"])])
    story.append(_table(risk_rows, [70, 70, 40, 300]))
    story.append(Paragraph("Mesut Kocagöz Dijital Karnesi", styles["TRH2"]))
    mrows = [r for r in rows if r.get("mesut_related") == 1]
    if mrows:
        tbl = [["Platform", "İlçe", "Duygu", "Başlık"]]
        for r in mrows[:12]:
            tbl.append([r.get("platform"), r.get("district"), r.get("sentiment"), Paragraph(str(r.get("title")), styles["TRBody"])])
        story.append(_table(tbl, [70, 80, 60, 270]))
    else:
        story.append(Paragraph("Bu dönemde Mesut Kocagöz bağlantılı içerik yakalanmadı.", styles["TRBody"]))
    story.append(Paragraph("Stratejik Notlar", styles["TRH2"]))
    for n in [
        "Mesut Kocagöz görünürlüğü yalnız Kepez içinde kalırsa hikaye daralır; Kepez dışı ilçelerde yerel hassasiyetlere bağlanan içerikler artırılmalıdır.",
        "Risk puanı yüksek ilçelerde doğrudan cevap vermeden önce konunun kaynağı, tonu ve yayılma hızı izlenmelidir.",
        "Fırsat puanı yüksek konular, samimi halk teması ve ilçe hassasiyeti ile ilişkilendirilmiş kısa içeriklere dönüştürülmelidir.",
        "Haftalık raporlar karar verici için kısa tutulmalı; aylık raporda ise 19 ilçe karşılaştırmalı harita mantığı kurulmalıdır."
    ]:
        story.append(Paragraph("- " + n, styles["TRBody"]))
    doc.build(story)
    return str(out_path)

def export_csv(days=7):
    rows = _load(days)
    REPORT_DIR.mkdir(exist_ok=True)
    path = REPORT_DIR / f"dijital_antalya_nabzi_{datetime.now().date()}_{days}gun.csv"
    if not rows:
        path.write_text("", encoding="utf-8")
        return str(path)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    return str(path)
