from datetime import datetime
from urllib.request import urlopen, Request
from xml.etree import ElementTree as ET
from src.utils import load_yaml, now_iso

def _txt(node, path):
    found = node.find(path)
    return "" if found is None or found.text is None else found.text

def collect_rss():
    sources = load_yaml("config/sources.yaml")
    items = []
    for src in sources.get("rss_sources", []):
        try:
            req = Request(src["url"], headers={"User-Agent": "DijitalAntalyaNabzi/0.1"})
            raw = urlopen(req, timeout=20).read()
            root = ET.fromstring(raw)
            for e in root.findall(".//item")[:20]:
                title = _txt(e, "title")
                summary = _txt(e, "description")
                link = _txt(e, "link")
                date = _txt(e, "pubDate") or datetime.now().date().isoformat()
                items.append({
                    "collected_at": now_iso(),
                    "date": date,
                    "platform": "rss",
                    "source": src["name"],
                    "title": title,
                    "text": summary,
                    "url": link
                })
        except Exception as exc:
            print(f"RSS kaynak okunamadı: {src.get('name')} - {exc}")
    return items
