# Dijital Antalya Nabzı - Mobil Kullanım Paketi

Bu sürüm iPhone'dan kullanıma göre düzenlendi.

## Mantık

Program telefonda çalışmaz. Program bulutta çalışır, sen iPhone'dan Safari ile panel linkini açarsın.

Önerilen yapı:

1. Kodlar GitHub reposunda durur.
2. GitHub Actions her gün otomatik `run_daily.py` çalıştırır.
3. Veriler ve raporlar repo içinde güncellenir.
4. Streamlit Community Cloud `mobile_app.py` dosyasını web paneli olarak yayınlar.
5. Sen iPhone'dan panel linkini ana ekrana eklersin.

## Telefonda kurulacak uygulama var mı?

Hayır. Safari yeterli.

## Panel dosyası

Streamlit'te entrypoint olarak şunu seç:

`mobile_app.py`

## Günlük otomasyon

`.github/workflows/daily.yml` her gün Türkiye saatiyle yaklaşık 09:10'da çalışacak şekilde ayarlandı.

## İlk test

Bilgisayarda veya GitHub Codespaces'te:

```bash
pip install -r requirements.txt
python run_daily.py --demo
python run_report.py --days 7
streamlit run mobile_app.py
```

## API anahtarları

API anahtarları GitHub Secrets veya Streamlit Secrets içine yazılmalıdır.

- X_BEARER_TOKEN
- YOUTUBE_API_KEY

API anahtarı yoksa sistem demo veri veya RSS kaynaklarıyla çalışır.

## iPhone kullanım

1. Streamlit panel linkini Safari'de aç.
2. Paylaş butonuna bas.
3. "Ana Ekrana Ekle" de.
4. Artık uygulama gibi açılır.

