import sqlite3
from pathlib import Path
import pandas as pd
import streamlit as st

DB = Path("data/antalya_nabzi.sqlite")

st.set_page_config(
    page_title="Dijital Antalya Nabzı",
    page_icon="📱",
    layout="centered",
    initial_sidebar_state="collapsed"
)

st.markdown("""
<style>
.block-container {padding-top: 1rem; padding-bottom: 2rem; max-width: 760px;}
[data-testid="stMetricValue"] {font-size: 1.45rem;}
.card {
    border: 1px solid #e5e7eb;
    border-radius: 14px;
    padding: 14px;
    margin: 10px 0;
    background: #ffffff;
    box-shadow: 0 1px 2px rgba(0,0,0,0.04);
}
.small {font-size: 0.86rem; color: #6b7280;}
.badge {
    display: inline-block;
    border-radius: 999px;
    padding: 2px 9px;
    font-size: 0.78rem;
    background: #eef2ff;
    color: #3730a3;
    margin-right: 4px;
}
.risk {background: #fee2e2; color: #991b1b;}
.opp {background: #dcfce7; color: #166534;}
</style>
""", unsafe_allow_html=True)

st.title("📱 Dijital Antalya Nabzı")
st.caption("Mobil panel - 7 günlük otomatik deneme")

if not DB.exists():
    st.warning("Veri bulunamadı. GitHub Actions veya run_daily.py çalıştıktan sonra panel dolacak.")
    st.info("Test için pakette demo veri bulunuyor.")
    st.stop()

conn = sqlite3.connect(DB)
df = pd.read_sql_query("SELECT * FROM items ORDER BY collected_at DESC", conn)
conn.close()

if df.empty:
    st.warning("Veri tabanı boş görünüyor.")
    st.stop()

# Filters
with st.expander("Filtreler", expanded=False):
    districts = ["Tümü"] + sorted(df["district"].dropna().unique().tolist())
    selected_district = st.selectbox("İlçe", districts)
    sentiments = ["Tümü"] + sorted(df["sentiment"].dropna().unique().tolist())
    selected_sentiment = st.selectbox("Duygu", sentiments)
    only_mesut = st.checkbox("Sadece Mesut Kocagöz bağlantılı içerikler")
    high_risk = st.checkbox("Sadece yüksek risk")
    high_opp = st.checkbox("Sadece yüksek fırsat")

view = df.copy()
if selected_district != "Tümü":
    view = view[view["district"] == selected_district]
if selected_sentiment != "Tümü":
    view = view[view["sentiment"] == selected_sentiment]
if only_mesut:
    view = view[view["mesut_related"] == 1]
if high_risk:
    view = view[view["risk_score"] >= 4]
if high_opp:
    view = view[view["opportunity_score"] >= 4]

c1, c2 = st.columns(2)
c1.metric("Toplam içerik", len(view))
c2.metric("Mesut bağlantılı", int(view["mesut_related"].sum()) if not view.empty else 0)
c3, c4 = st.columns(2)
c3.metric("Yüksek risk", int((view["risk_score"] >= 4).sum()) if not view.empty else 0)
c4.metric("Yüksek fırsat", int((view["opportunity_score"] >= 4).sum()) if not view.empty else 0)

tab1, tab2, tab3, tab4 = st.tabs(["Özet", "İlçeler", "Mesut", "Akış"])

with tab1:
    st.subheader("Bugünün hızlı özeti")
    if view.empty:
        st.info("Filtreye uygun içerik yok.")
    else:
        top_topics = view.groupby("topic").size().sort_values(ascending=False).head(5)
        for topic, count in top_topics.items():
            st.markdown(f"<div class='card'><b>{topic}</b><br><span class='small'>{count} içerik</span></div>", unsafe_allow_html=True)

        st.subheader("Riskli başlıklar")
        risky = view.sort_values("risk_score", ascending=False).head(5)
        for _, r in risky.iterrows():
            st.markdown(
                f"<div class='card'><span class='badge risk'>Risk {r['risk_score']}</span>"
                f"<span class='badge'>{r['district']}</span><br><b>{r['title']}</b>"
                f"<p class='small'>{r['summary']}</p></div>",
                unsafe_allow_html=True
            )

with tab2:
    st.subheader("İlçe görünürlüğü")
    if not view.empty:
        dist = view.groupby("district").size().sort_values(ascending=False).head(19)
        st.bar_chart(dist)
        for d, cnt in dist.items():
            st.markdown(f"<div class='card'><b>{d}</b><br><span class='small'>{cnt} içerik</span></div>", unsafe_allow_html=True)

with tab3:
    st.subheader("Mesut Kocagöz dijital karnesi")
    mdf = df[df["mesut_related"] == 1]
    if mdf.empty:
        st.info("Mesut Kocagöz bağlantılı içerik yok.")
    else:
        c1, c2 = st.columns(2)
        c1.metric("Toplam görünürlük", len(mdf))
        c2.metric("Olumlu içerik", int((mdf["sentiment"] == "olumlu").sum()))
        st.write("En son içerikler")
        for _, r in mdf.head(10).iterrows():
            st.markdown(
                f"<div class='card'><span class='badge'>{r['platform']}</span>"
                f"<span class='badge'>{r['district']}</span><br><b>{r['title']}</b>"
                f"<p class='small'>{r['summary']}</p></div>",
                unsafe_allow_html=True
            )

with tab4:
    st.subheader("İçerik akışı")
    if view.empty:
        st.info("Filtreye uygun içerik yok.")
    else:
        for _, r in view.head(30).iterrows():
            risk_class = "risk" if r["risk_score"] >= 4 else ""
            opp_class = "opp" if r["opportunity_score"] >= 4 else ""
            st.markdown(
                f"<div class='card'>"
                f"<span class='badge'>{r['platform']}</span>"
                f"<span class='badge'>{r['district']}</span>"
                f"<span class='badge'>{r['topic']}</span>"
                f"<span class='badge {risk_class}'>Risk {r['risk_score']}</span>"
                f"<span class='badge {opp_class}'>Fırsat {r['opportunity_score']}</span>"
                f"<br><b>{r['title']}</b>"
                f"<p class='small'>{r['summary']}</p>"
                f"<a href='{r['url']}' target='_blank'>Kaynağı aç</a>"
                f"</div>",
                unsafe_allow_html=True
            )

st.caption("Not: Bu panel kamuya açık veri takibi ve raporlama içindir. Kapalı gruplar, kişisel veri veya yapay etkileşim üretimi için kullanılmaz.")
