from pathlib import Path
import yaml
from datetime import datetime

def load_yaml(path):
    return yaml.safe_load(Path(path).read_text(encoding="utf-8"))

def now_iso():
    return datetime.now().isoformat(timespec="seconds")

def normalize(text):
    return (text or "").lower().replace("ı", "i").replace("İ", "i")
