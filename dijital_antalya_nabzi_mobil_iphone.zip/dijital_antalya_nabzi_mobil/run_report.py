import argparse
from src.reporter import generate_pdf, export_csv

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=7)
    args = parser.parse_args()
    csv_path = export_csv(args.days)
    pdf_path = generate_pdf(args.days)
    print("CSV:", csv_path)
    print("PDF:", pdf_path)

if __name__ == "__main__":
    main()
