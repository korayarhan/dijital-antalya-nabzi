import sqlite3
from pathlib import Path
import pandas as pd
import streamlit as st

DB = Path("data/antalya_nabzi.sqlite")
st.set_page_config(page_title="Dijital Antalya Nabzı", layout="wide")
st.title("Dijital Antalya Nabzı - 7 Günlük Deneme Paneli")

if not DB.exists():
    st.warning("Veritabanı bulunamadı. Önce `python run_daily.py --demo` çalıştır.")
    st.stop()

conn = sqlite3.connect(DB)
df = pd.read_sql_query("SELECT * FROM items ORDER BY collected_at DESC", conn)
conn.close()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Toplam içerik", len(df))
c2.metric("Mesut bağlantılı", int(df["mesut_related"].sum()))
c3.metric("Yüksek risk", int((df["risk_score"] >= 4).sum()))
c4.metric("Yüksek fırsat", int((df["opportunity_score"] >= 4).sum()))

st.subheader("İlçe dağılımı")
st.bar_chart(df.groupby("district").size().sort_values(ascending=False))

st.subheader("Konu dağılımı")
st.bar_chart(df.groupby("topic").size().sort_values(ascending=False))

st.subheader("İçerik akışı")
districts = ["Tümü"] + sorted(df["district"].dropna().unique().tolist())
selected = st.selectbox("İlçe", districts)
view = df if selected == "Tümü" else df[df["district"] == selected]
st.dataframe(view[["date","platform","source","district","topic","sentiment","risk_score","opportunity_score","mesut_related","title","url"]], use_container_width=True)
