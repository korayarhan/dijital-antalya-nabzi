import argparse, os
from dotenv import load_dotenv
from src.analyzer import analyze_item
from src.db import upsert_items
from src.collectors.demo_collector import collect_demo
from src.collectors.rss_collector import collect_rss
from src.collectors.x_collector import collect_x_recent
from src.collectors.youtube_collector import collect_youtube_search
from src.utils import load_yaml

def main():
    load_dotenv()
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true", help="Demo veriyle çalıştır")
    args = parser.parse_args()
    items = []
    if args.demo:
        items.extend(collect_demo())
    else:
        items.extend(collect_rss())
        sources = load_yaml("config/sources.yaml")
        x_query = '"Mesut Kocagöz" OR "Mesut Başkan" OR "Kepez Belediyesi" OR "Antalya Büyükşehir"'
        items.extend(collect_x_recent(x_query, max_results=25))
        for q in sources.get("google_news_queries", [])[:3]:
            items.extend(collect_youtube_search(q, max_results=5))
        if not items:
            print("Gerçek kaynaklardan veri gelmedi. Demo veriye düşülüyor.")
            items.extend(collect_demo())
    analyzed = [analyze_item(dict(i)) for i in items]
    upsert_items(analyzed)
    print(f"{len(analyzed)} içerik işlendi ve veritabanına yazıldı.")

if __name__ == "__main__":
    main()
