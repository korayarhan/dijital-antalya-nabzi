import os, requests
from src.utils import now_iso

def collect_x_recent(query, max_results=25):
    token = os.getenv("X_BEARER_TOKEN")
    if not token:
        return []
    url = "https://api.x.com/2/tweets/search/recent"
    params = {
        "query": query,
        "max_results": max(10, min(max_results, 100)),
        "tweet.fields": "created_at,public_metrics,lang",
    }
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get(url, params=params, headers=headers, timeout=30)
    r.raise_for_status()
    data = r.json().get("data", [])
    items = []
    for t in data:
        items.append({
            "collected_at": now_iso(),
            "date": t.get("created_at", ""),
            "platform": "x",
            "source": "X recent search",
            "title": t.get("text", "")[:80],
            "text": t.get("text", ""),
            "url": f"https://x.com/i/web/status/{t.get('id')}"
        })
    return items
