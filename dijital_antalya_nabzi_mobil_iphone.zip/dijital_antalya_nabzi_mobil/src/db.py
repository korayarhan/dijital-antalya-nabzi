import sqlite3
from pathlib import Path

DB_PATH = Path("data/antalya_nabzi.sqlite")

def connect():
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
    CREATE TABLE IF NOT EXISTS items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        collected_at TEXT,
        date TEXT,
        platform TEXT,
        source TEXT,
        title TEXT,
        text TEXT,
        url TEXT UNIQUE,
        district TEXT,
        topic TEXT,
        sentiment TEXT,
        risk_score INTEGER,
        opportunity_score INTEGER,
        mesut_related INTEGER,
        summary TEXT
    )
    """)
    return conn

def upsert_items(items):
    conn = connect()
    cur = conn.cursor()
    for item in items:
        cur.execute("""
        INSERT OR IGNORE INTO items (
            collected_at, date, platform, source, title, text, url,
            district, topic, sentiment, risk_score, opportunity_score,
            mesut_related, summary
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            item.get("collected_at"), item.get("date"), item.get("platform"),
            item.get("source"), item.get("title"), item.get("text"), item.get("url"),
            item.get("district"), item.get("topic"), item.get("sentiment"),
            item.get("risk_score"), item.get("opportunity_score"),
            int(item.get("mesut_related", 0)), item.get("summary")
        ))
    conn.commit()
    conn.close()
